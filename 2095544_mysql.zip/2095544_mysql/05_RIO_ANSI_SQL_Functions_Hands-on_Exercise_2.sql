
select upper(Student_name) from student_info;
select upper(branch) from student_info;

select lower(Weightage) from subject_master;

select concat('Age =', floor((current_date - Date_of_Birth)/4380))  from student_info;

select Reg_number,avg(GPA) from student_result;

select Reg_number,max(GPA) from student_result;

select reg_number, max(marks) from student_marks
where subject_code='EI05IP';

SELECT Stu_name,branch,contact,Date_of_Birth,Date_of_Joining,Address,
case when Email_id Is null then 'no valid Email_id' else Email_id end from Student_info;