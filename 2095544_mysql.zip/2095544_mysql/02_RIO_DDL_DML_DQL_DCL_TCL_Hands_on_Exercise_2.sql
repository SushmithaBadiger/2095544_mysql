drop table Student_info;
create database Student_info;
Use Student_info;
create table Student_info(
Regestration_no varchar(30),
Stu_Name varchar(40),
Branch varchar(30),
Contact double,
Date_of_Birth date,
Date_of_Joining date,
Address varchar(200),
Email_id varchar(100)
);

create table Subject_Master(
Subject_Code varchar(30),
Subject_Name varchar(60),
Wei_for_GPA int
);
create database Student_marks;
use Student_marks;
create table Student_marks(
Reg_Number varchar(20),
Subject_Code varchar(10),
Semester int,
marks int
); 

create table Student_Result(
Reg_Number varchar(10),
Semester int,
GPA float,
Is_Eligible char(3)
);

insert into student_info values
('MC101301','James','MCA',9714589787,'1984-01-12','2010-07-08','No 10,South Block,Nivea','james.mca@yahoo.com');
insert into student_info values
('BEC111402','Manio','ECE',8912457875,'1983-02-23','2011-06-25','8/12,Park View,Sieera','manioma@gmail.com');
insert into student_info values
('BEEI1001204','Mike','EI',8974567897,'1983-02-10','2010-08-25','Cross villa,NY','mike.james@ymail.com');
insert into student_info values
('MB111305','Paulson','MBA',8547986123,'1984-12-13','2010-08-08','Lake view,NJ','paul.son@rediffmail.com');

insert into Subject_Master values('EE01DCF',' DCF',' 30');
insert into Subject_Master values('EC02MUP',' Microprocessor',' 40');
insert into Subject_Master values('MC06DIP',' Digital Image Processing',' 30');
insert into Subject_Master values('MB03MAR',' Marketing Techniques',' 20');
insert into Subject_Master values('EI05IP',' Instrumentation Precision',' 40');
insert into Subject_Master values('CPSC02DS',' Data Structures',' 40');

insert into student_marks values('MC101301',' EE01DCF',' 1',' 75');
insert into student_marks values('MC101301',' EC02MUP',' 1',' 65');
insert into student_marks values('MC101301',' MC06DIP',' 1',' 70');
insert into student_marks values('BEC111402',' EE01DCF',' 1',' 55');
insert into student_marks values('BEC111402',' EC02MUP',' 1',' 80');
insert into student_marks values('BEC111402',' MC06DIP',' 1',' 60');
insert into student_marks values('BEEI101204',' EE01DCF',' 1',' 85');
insert into student_marks values('BEEI101204',' EC02MUP',' 1',' 78');
insert into student_marks values('BEEI101204',' MC06DIP',' 1',' 80');
insert into student_marks values('BEEI101204',' MB03MAR',' 2',' 75');
insert into student_marks values('BEEI101204',' EI05IP',' 2',' 65');
insert into student_marks values('BEEI101204',' CPSC02DS',' 2',' 75');
insert into student_marks values('MB111305',' EE01DCF',' 1',' 65');
insert into student_marks values('MB111305',' EC02MUP',' 1',' 68');
insert into student_marks values('MB111305',' MC06DIP',' 1',' 63');
insert into student_marks values('MB111305',' MB03MAR',' 2',' 85');
insert into student_marks values('MB111305',' EI05IP',' 2',' 74');
insert into student_marks values('MB111305',' CPSC02DS',' 2',' 62');

insert into student_result values('MC101301',' 1',' 7.5',' Y');
insert into student_result values('BEC111402',' 1',' 7.1',' Y');
insert into student_result values('BEEI101204',' 1',' 8.3',' Y');
insert into student_result values('BEEI101204',' 2',' 6.9',' N');
insert into student_result values('MB111305',' 1',' 6.5',' N');
insert into student_result values('MB111305',' 2',' 6.8',' N');


