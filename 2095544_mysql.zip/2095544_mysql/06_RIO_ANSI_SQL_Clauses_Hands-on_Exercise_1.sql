create database employee_info;
use employee_info;
create table employee_info(employee_id varchar(20), employee_name varchar(30),
date_of_joining date, age int, salary double);
select *from employee_info;
insert into employee_info values
('F001','Ram','2021-12-01', 23, 25000.00),
('F002', 'Sham','2021-12-03', 25, 23000.00),
('F003', 'Vinod','2021-12-05', 24, 22500.00),
('F004','kumar','2021-12-21', 25, 23000.00),
('F005','Raj','2021-12-15', 23, 24000.00),
('F006', 'dev','2021-12-01', 26, 24500.00),
('F007','shiv', '2021-12-03',29, 24000.00),
('F008','manju','2021-12-19',27,23000.00),
('F009',' Prem','2021-12-19', 28, 26000.00),
('F0010','karan','2021-12-05',30,28000.00);
select age from employee_info;
select date_of_joining, count(employee_id)
from employee_info where employee_id='F001' group by date_of_joining;
select date_of_joining, count(employee_id)
from employee_info where employee_id='F001'
group by date_of_joining having count(employee_id)>=2;
select age from employee_info order by age;
select employee_id, employee_name, salary from employee_info order by salary desc;