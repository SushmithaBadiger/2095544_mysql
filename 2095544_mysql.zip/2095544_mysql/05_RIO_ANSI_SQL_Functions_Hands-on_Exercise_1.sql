alter table module_info add column module_fees decimal(10,4);


UPDATE module_info
SET module_Name = CONCAT(UCASE(LEFT(module_Name, 1)), LCASE(SUBSTRING(module_Name, 2)));

UPDATE module_info
SET module_Id = CONCAT(UCASE(LEFT(module_Id, 1)), LCASE(SUBSTRING(module_Id, 2)));

select concat(module_name,module_id) from module_info;


Select upper(Module_Name) from module_info;

select substring(Module_name,1,3) from module_info;

SELECT AVG(ISNULL(base_fees,0)) FROM module_info;

select 100000+cast(Trainer_Id as decimal) from trainer_info;

select concat('The Base Fees Amount for the module name', module_info.Module_Name, 
cast(module_info.Base_Fees as decimal)) from module_info;

select count(*) from Module_Info;

select sum(base_fees) from Module_Fees;

select min(base_fees), max(base_fees) from Module_Fees;

