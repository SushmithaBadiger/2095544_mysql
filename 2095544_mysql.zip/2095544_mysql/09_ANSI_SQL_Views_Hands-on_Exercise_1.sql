create unique index index_2 on associate_info(associate_name);

alter table associate_info drop index index_2;

create view view_3 as select associate_id , trainer_id, batch_id 
from associate_status with cascaded check option;

select * from view_3;

create or replace view view_4 as select associate_id, trainer_id, batch_id 
from associate_status with local check option;

select * from view_4;
